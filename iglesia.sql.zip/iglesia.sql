-- phpMyAdmin SQL Dump
-- version 2.10.3
-- http://www.phpmyadmin.net
-- 
-- Servidor: localhost
-- Tiempo de generación: 11-10-2014 a las 14:06:22
-- Versión del servidor: 5.0.51
-- Versión de PHP: 5.2.6

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";

-- 
-- Base de datos: `iglesia`
-- 

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `bautizos`
-- 

CREATE TABLE `bautizos` (
  `IDBAUTIZO` bigint(50) NOT NULL auto_increment,
  `NUMEROBAU` bigint(20) NOT NULL,
  `CASADO` varchar(300) character set utf8 collate utf8_bin default NULL,
  `FECHACASADO` date default NULL,
  `REGISTROCIVIL` varchar(300) NOT NULL,
  `TOMO` int(11) NOT NULL,
  `PAGINA` int(11) NOT NULL,
  `NUMERO` int(11) NOT NULL,
  `FECHAINSCRIPCION` date NOT NULL,
  `FECHABAUTIZO` date NOT NULL,
  `CIUDADNAC` varchar(200) NOT NULL,
  `GENERO` varchar(2) NOT NULL,
  `IDPER` bigint(20) NOT NULL,
  `IDPAR` int(11) NOT NULL,
  `IDPAD` bigint(20) NOT NULL,
  `IDPAD2` bigint(20) NOT NULL,
  `ACTIVO` varchar(2) NOT NULL,
  `idiglesias` int(11) NOT NULL,
  PRIMARY KEY  (`IDBAUTIZO`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

-- 
-- Volcar la base de datos para la tabla `bautizos`
-- 


-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `catecismo`
-- 

CREATE TABLE `catecismo` (
  `IDCATE` bigint(50) NOT NULL auto_increment,
  `FICHA` bigint(50) default NULL,
  `FECHAINS` date NOT NULL,
  `IDESTPADRES` bigint(50) default NULL,
  `GENERO` varchar(2) NOT NULL,
  `BAUTIZO` varchar(2) NOT NULL,
  `IDNIVEL` int(11) NOT NULL,
  `ACTA` varchar(45) default NULL,
  `FECHABAUTIZO` date default NULL,
  `ARCHIVOAPRO` text,
  `DIRECCION` text,
  `PARROQUIA` varchar(300) default NULL,
  `LOCALIDAD` varchar(300) default NULL,
  `PARROCO` varchar(300) default NULL,
  `ACTIVO` varchar(2) NOT NULL default 'SI',
  `idiglesia` int(11) NOT NULL,
  PRIMARY KEY  (`IDCATE`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=12 ;

-- 
-- Volcar la base de datos para la tabla `catecismo`
-- 


-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `catequistas`
-- 

CREATE TABLE `catequistas` (
  `IDCATEQUISTA` bigint(50) NOT NULL auto_increment,
  `IDPERSONA` bigint(50) NOT NULL,
  `GENERO` varchar(2) NOT NULL,
  `FECHAINGRESO` date NOT NULL,
  `idiglesia` int(11) NOT NULL,
  PRIMARY KEY  (`IDCATEQUISTA`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=5 ;

-- 
-- Volcar la base de datos para la tabla `catequistas`
-- 


-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `configuracion`
-- 

CREATE TABLE `configuracion` (
  `IDCONFI` bigint(50) NOT NULL auto_increment,
  `FONDOCOLOR` varchar(100) character set utf8 collate utf8_bin NOT NULL,
  `activo` varchar(2) NOT NULL,
  `TIPO` int(11) NOT NULL,
  PRIMARY KEY  (`IDCONFI`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=18 ;

-- 
-- Volcar la base de datos para la tabla `configuracion`
-- 

INSERT INTO `configuracion` VALUES (1, 0x696d67666f6e646f312e6a7067, 'NO', 1);
INSERT INTO `configuracion` VALUES (2, 0x696d67666f6e646f322e6a7067, 'SI', 1);
INSERT INTO `configuracion` VALUES (3, 0x696d67666f6e646f332e6a7067, 'NO', 1);
INSERT INTO `configuracion` VALUES (4, 0x696d67666f6e646f342e6a7067, 'NO', 1);
INSERT INTO `configuracion` VALUES (5, 0x696d67666f6e646f352e6a7067, 'NO', 1);
INSERT INTO `configuracion` VALUES (6, 0x696d67666f6e646f362e6a7067, 'NO', 1);
INSERT INTO `configuracion` VALUES (7, 0x696d67666f6e646f372e6a7067, 'NO', 1);
INSERT INTO `configuracion` VALUES (8, 0x696d67666f6e646f382e6a7067, 'NO', 1);
INSERT INTO `configuracion` VALUES (9, 0x696d67666f6e646f392e6a7067, 'NO', 1);
INSERT INTO `configuracion` VALUES (10, 0x696d67666f6e646f31302e6a7067, 'NO', 2);
INSERT INTO `configuracion` VALUES (11, 0x696d67666f6e646f31312e6a7067, 'SI', 2);
INSERT INTO `configuracion` VALUES (12, 0x696d67666f6e646f31322e6a7067, 'NO', 2);
INSERT INTO `configuracion` VALUES (13, 0x696d67666f6e646f31332e6a7067, 'NO', 2);
INSERT INTO `configuracion` VALUES (14, 0x696d67666f6e646f31302e6a7067, 'NO', 3);
INSERT INTO `configuracion` VALUES (15, 0x696d67666f6e646f31312e6a7067, 'NO', 3);
INSERT INTO `configuracion` VALUES (16, 0x696d67666f6e646f31322e6a7067, 'SI', 3);
INSERT INTO `configuracion` VALUES (17, 0x696d67666f6e646f31332e6a7067, 'NO', 3);

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `confirmas`
-- 

CREATE TABLE `confirmas` (
  `IDCONFIRMAS` bigint(50) NOT NULL auto_increment,
  `NUMEROCONF` int(11) NOT NULL,
  `FECHACONFIRMA` date NOT NULL,
  `FECHABAUTIZO` date NOT NULL,
  `LUGAR` varchar(300) default NULL,
  `IDPER` bigint(20) NOT NULL,
  `GENERO` varchar(2) NOT NULL,
  `IDPAD` bigint(20) NOT NULL,
  `IDPAR` int(11) NOT NULL,
  `ACTIVO` char(2) NOT NULL,
  `idiglesia` int(11) NOT NULL,
  PRIMARY KEY  (`IDCONFIRMAS`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

-- 
-- Volcar la base de datos para la tabla `confirmas`
-- 


-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `datosiglesia`
-- 

CREATE TABLE `datosiglesia` (
  `IDIGLESIA` bigint(50) NOT NULL auto_increment,
  `NOMBRE` varchar(30) character set utf8 collate utf8_bin NOT NULL,
  `PARROQUIA` varchar(100) character set utf8 collate utf8_bin NOT NULL,
  `DIRECCION` varchar(100) character set utf8 collate utf8_bin default NULL,
  `FONO` varchar(22) character set utf8 collate utf8_bin default NULL,
  `ACTIVO` char(2) NOT NULL,
  PRIMARY KEY  (`IDIGLESIA`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

-- 
-- Volcar la base de datos para la tabla `datosiglesia`
-- 

INSERT INTO `datosiglesia` VALUES (1, 0x53414e204a4f53c389, 0x42414348494c4c45524f, 0x544f5341475541, 0x313233, 'SI');

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `estudiante_requisitos`
-- 

CREATE TABLE `estudiante_requisitos` (
  `IDESTREQ` bigint(50) NOT NULL auto_increment,
  `IDCATE` bigint(50) default NULL,
  `IDREQ` bigint(50) default NULL,
  PRIMARY KEY  (`IDESTREQ`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=28 ;

-- 
-- Volcar la base de datos para la tabla `estudiante_requisitos`
-- 


-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `frases`
-- 

CREATE TABLE `frases` (
  `IDFRASE` bigint(50) NOT NULL auto_increment,
  `FRASE` text character set utf8 collate utf8_bin,
  `VENTANA` int(11) NOT NULL,
  `activo` varchar(2) NOT NULL,
  PRIMARY KEY  (`IDFRASE`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=16 ;

-- 
-- Volcar la base de datos para la tabla `frases`
-- 

INSERT INTO `frases` VALUES (1, 0x22544f444f204c4f20505545444f20454e2043524953544f20515545204d4520464f5254414c45434522202846494c4950454e53455320343a313329, 1, 'SI');
INSERT INTO `frases` VALUES (2, 0x224e6f206e6f73206861206461646f2044696f7320657370c3ad7269747520646520636f62617264c3ad612c2073696e6f20646520706f6465722c20646520616d6f72207920646520646f6d696e696f2070726f70696f22202854696d6f74656f20343a313329, 2, 'SI');
INSERT INTO `frases` VALUES (3, 0x224573746520657320656c2064c3ad61207175652068697a6f20656c205365c3b16f723a20616c656772c3a96d6f6e6f732079207265676f63696ac3a96d6f6e6f7320656e20c3a96c22202853616c6d6f73203131383a323429, 3, 'SI');
INSERT INTO `frases` VALUES (4, 0x2244696f73206573206e75657374726f20616d7061726f207920666f7274616c657a612c206e75657374726f20617578696c696f20656e206c61732074726962756c6163696f6e657322202853616c6d6f732034363a3129, 4, 'SI');
INSERT INTO `frases` VALUES (5, 0x224e6f206f6672657a63617320612064696f732073c3b36c6f20656c20646f6c6f72206465207475732070656e6974656e636961732c206f6672c3a963656c652074616d6269c3a96e2074757320616c656772c3ad617322205061756c6f20436f656c686f, 5, 'SI');
INSERT INTO `frases` VALUES (6, 0x22437265657220656e2064696f732065732061636570746172206e75657374726120646562696c69646164207920636f6e6669617220656e20c3a96c2220446f6dc3a96e69636f2043696572692045737472616461, 6, 'SI');
INSERT INTO `frases` VALUES (7, 0x224c652064696a6f204a6573c3ba733a20596f20736f79206c612072657375727265636369c3b36e2079206c6120766964613b20656c20717565206372656520656e206dc3ad2c2061756e71756520657374c3a9206d756572746f2c207669766972c3a12220284a75616e2031313a323529, 7, 'SI');
INSERT INTO `frases` VALUES (8, 0x6672617365207265706f727465, 8, 'SI');
INSERT INTO `frases` VALUES (9, 0x2244696f7320656e7469656e6465206e75657374726173206f726163696f6e65732061756e206375616e646f206e6f736f74726f73206e6f20706f64656d6f7320656e636f6e74726172206c61732070616c616272617320706172612065787072657361726c617322204175746f7220446573636f6e6f6369646f, 12, 'SI');
INSERT INTO `frases` VALUES (10, 0x22446172206772616369617320612064696f7320706f72206c6f20717565207365207469656e652c20616c6cc3ad20636f6d69656e7a6120656c20617274652064652076697669722220446f6dc3a96e69636f2043696572692045737472616461, 13, 'SI');
INSERT INTO `frases` VALUES (11, 0x224c6120636f6e6669616e7a6120656e2073c3ad206d69736d6f20657320656c207072696d6572207365637265746f2064656c20c3a97869746f222052616c70682057616c646f20456d6572736f6e2e, 15, 'SI');
INSERT INTO `frases` VALUES (12, 0x22556e206d617472696d6f6e696f2066656c697a206573206c6120756e69c3b36e20646520646f73206275656e6f7320706572646f6e61646f7265732220527574682042656c6c2047726168616d2e, 11, 'SI');
INSERT INTO `frases` VALUES (13, 0x224c6120667565727a61206e6f207669656e65206465206c612063617061636964616420636f72706f72616c2c2073696e6f206465206c6120766f6c756e7461642064656c20616c6d61222047616e646869, 10, 'SI');
INSERT INTO `frases` VALUES (14, 0x22416e74657320717565206e6164612c206c6120707265706172616369c3b36e206573206c61206c6c6176652064656c20c3a97869746f2220416c6578616e6465722047726168616d2042656c6c, 9, 'SI');
INSERT INTO `frases` VALUES (15, 0x224c6120696e6e6f76616369c3b36e2064697374696e67756520756e206cc3ad64657220646520756e207365677569646f7222205374657665204a6f6273, 14, 'SI');

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `matrimonios`
-- 

CREATE TABLE `matrimonios` (
  `IDMATRIMONIO` bigint(50) NOT NULL auto_increment,
  `ACTAMATRIMONIAL` bigint(20) NOT NULL,
  `LUGAR` varchar(300) character set utf8 collate utf8_bin NOT NULL,
  `ANIO` varchar(300) NOT NULL,
  `TOMO` int(11) NOT NULL,
  `PAGINA` int(11) NOT NULL,
  `NUMERO` int(11) NOT NULL,
  `LUGARIGLESIA` varchar(300) NOT NULL,
  `FECHAPRESENTACION` date NOT NULL,
  `FECHAMATRIMONIO` date NOT NULL,
  `ARCHIVOCANO` text,
  `CURSOPRE` varchar(2) NOT NULL,
  `IDPAR` int(11) NOT NULL,
  `IDNOVIO` bigint(50) NOT NULL,
  `FECHABAUTIZON1` date NOT NULL,
  `CIUDADN1` varchar(300) NOT NULL,
  `IGLESIAN1` varchar(300) NOT NULL,
  `IDNOVIA` bigint(50) NOT NULL,
  `FECHABAUTIZON2` date NOT NULL,
  `CIUDADN2` varchar(300) NOT NULL,
  `IGLESIAN2` varchar(300) NOT NULL,
  `TESTIGO1` bigint(50) NOT NULL,
  `TESTIGO2` bigint(50) NOT NULL,
  `IDPAD1` bigint(50) NOT NULL,
  `IDPAD2` bigint(50) NOT NULL,
  `ACTIVO` char(2) NOT NULL,
  `idiglesia` int(11) NOT NULL,
  PRIMARY KEY  (`IDMATRIMONIO`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

-- 
-- Volcar la base de datos para la tabla `matrimonios`
-- 


-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `niveles`
-- 

CREATE TABLE `niveles` (
  `IDNIVEL` bigint(50) NOT NULL auto_increment,
  `NOMBRE` varchar(100) character set utf8 collate utf8_bin NOT NULL,
  `ACTIVO` char(2) NOT NULL,
  `idiglesia` int(11) NOT NULL,
  PRIMARY KEY  (`IDNIVEL`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=7 ;

-- 
-- Volcar la base de datos para la tabla `niveles`
-- 

INSERT INTO `niveles` VALUES (1, 0x494e494349414c495a414349c3934e, 'SI', 1);
INSERT INTO `niveles` VALUES (2, 0x5052494d4552204e4956454c20444520434f4d554e49c3934e, 'SI', 1);
INSERT INTO `niveles` VALUES (3, 0x534547554e444f204e4956454c20444520434f4d554e49c3934e, 'SI', 1);
INSERT INTO `niveles` VALUES (4, 0x41c3914f2042c38d424c49434f, 'SI', 1);
INSERT INTO `niveles` VALUES (5, 0x5052494d4552204e4956454c20444520434f4e4649524d414349c3934e, 'SI', 1);
INSERT INTO `niveles` VALUES (6, 0x534547554e444f204e4956454c20444520434f4e4649524d414349c3934e, 'SI', 1);

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `parroco`
-- 

CREATE TABLE `parroco` (
  `IDPARROCO` bigint(50) NOT NULL auto_increment,
  `IDPERSONA` int(11) NOT NULL,
  `FECHAINGRESO` date NOT NULL,
  `idiglesia` int(11) NOT NULL,
  PRIMARY KEY  (`IDPARROCO`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

-- 
-- Volcar la base de datos para la tabla `parroco`
-- 

INSERT INTO `parroco` VALUES (1, 1, '2014-09-25', 1);

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `permisos-usuarios`
-- 

CREATE TABLE `permisos-usuarios` (
  `IDPERMISO` bigint(50) NOT NULL auto_increment,
  `IDUSU` bigint(50) NOT NULL,
  `IDVEN` bigint(50) NOT NULL,
  `INSERTAR` varchar(2) default 'NO',
  `ACTUALIZAR` varchar(2) default 'NO',
  `CONSULTAR` varchar(2) default 'NO',
  PRIMARY KEY  (`IDPERMISO`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=49 ;

-- 
-- Volcar la base de datos para la tabla `permisos-usuarios`
-- 

INSERT INTO `permisos-usuarios` VALUES (48, 4, 16, 'NO', 'NO', 'NO');
INSERT INTO `permisos-usuarios` VALUES (47, 4, 15, 'NO', 'NO', 'NO');
INSERT INTO `permisos-usuarios` VALUES (46, 4, 14, 'NO', 'NO', 'NO');
INSERT INTO `permisos-usuarios` VALUES (45, 4, 13, 'NO', 'NO', 'NO');
INSERT INTO `permisos-usuarios` VALUES (44, 4, 12, 'NO', 'NO', 'NO');
INSERT INTO `permisos-usuarios` VALUES (43, 4, 11, 'NO', 'NO', 'SI');
INSERT INTO `permisos-usuarios` VALUES (42, 4, 10, 'NO', 'NO', 'SI');
INSERT INTO `permisos-usuarios` VALUES (41, 4, 9, 'NO', 'NO', 'SI');
INSERT INTO `permisos-usuarios` VALUES (40, 4, 8, 'NO', 'NO', 'SI');
INSERT INTO `permisos-usuarios` VALUES (39, 4, 7, 'NO', 'NO', 'NO');
INSERT INTO `permisos-usuarios` VALUES (38, 4, 6, 'NO', 'NO', 'NO');
INSERT INTO `permisos-usuarios` VALUES (37, 4, 5, 'NO', 'NO', 'NO');
INSERT INTO `permisos-usuarios` VALUES (36, 4, 4, 'NO', 'NO', 'NO');
INSERT INTO `permisos-usuarios` VALUES (35, 4, 3, 'NO', 'NO', 'SI');
INSERT INTO `permisos-usuarios` VALUES (34, 4, 2, 'NO', 'NO', 'SI');
INSERT INTO `permisos-usuarios` VALUES (33, 4, 1, 'NO', 'NO', 'SI');
INSERT INTO `permisos-usuarios` VALUES (32, 3, 16, 'SI', 'SI', 'SI');
INSERT INTO `permisos-usuarios` VALUES (31, 3, 15, 'SI', 'SI', 'NO');
INSERT INTO `permisos-usuarios` VALUES (30, 3, 14, 'NO', 'NO', 'NO');
INSERT INTO `permisos-usuarios` VALUES (29, 3, 13, 'SI', 'SI', 'SI');
INSERT INTO `permisos-usuarios` VALUES (28, 3, 12, 'NO', 'NO', 'NO');
INSERT INTO `permisos-usuarios` VALUES (27, 3, 11, 'NO', 'NO', 'SI');
INSERT INTO `permisos-usuarios` VALUES (26, 3, 10, 'NO', 'NO', 'SI');
INSERT INTO `permisos-usuarios` VALUES (25, 3, 9, 'NO', 'NO', 'SI');
INSERT INTO `permisos-usuarios` VALUES (24, 3, 8, 'NO', 'NO', 'SI');
INSERT INTO `permisos-usuarios` VALUES (23, 3, 7, 'NO', 'NO', 'SI');
INSERT INTO `permisos-usuarios` VALUES (22, 3, 6, 'NO', 'NO', 'SI');
INSERT INTO `permisos-usuarios` VALUES (21, 3, 5, 'NO', 'NO', 'SI');
INSERT INTO `permisos-usuarios` VALUES (20, 3, 4, 'NO', 'NO', 'SI');
INSERT INTO `permisos-usuarios` VALUES (19, 3, 3, 'NO', 'NO', 'SI');
INSERT INTO `permisos-usuarios` VALUES (18, 3, 2, 'NO', 'NO', 'SI');
INSERT INTO `permisos-usuarios` VALUES (17, 3, 1, 'NO', 'NO', 'SI');
INSERT INTO `permisos-usuarios` VALUES (16, 2, 16, 'SI', 'SI', 'SI');
INSERT INTO `permisos-usuarios` VALUES (15, 2, 15, 'NO', 'SI', 'NO');
INSERT INTO `permisos-usuarios` VALUES (14, 2, 14, 'NO', 'NO', 'NO');
INSERT INTO `permisos-usuarios` VALUES (13, 2, 13, 'NO', 'SI', 'SI');
INSERT INTO `permisos-usuarios` VALUES (12, 2, 12, 'NO', 'NO', 'NO');
INSERT INTO `permisos-usuarios` VALUES (11, 2, 11, 'NO', 'NO', 'SI');
INSERT INTO `permisos-usuarios` VALUES (10, 2, 10, 'NO', 'NO', 'SI');
INSERT INTO `permisos-usuarios` VALUES (9, 2, 9, 'NO', 'NO', 'SI');
INSERT INTO `permisos-usuarios` VALUES (8, 2, 8, 'NO', 'NO', 'SI');
INSERT INTO `permisos-usuarios` VALUES (7, 2, 7, 'NO', 'SI', 'SI');
INSERT INTO `permisos-usuarios` VALUES (6, 2, 6, 'NO', 'SI', 'SI');
INSERT INTO `permisos-usuarios` VALUES (5, 2, 5, 'NO', 'SI', 'SI');
INSERT INTO `permisos-usuarios` VALUES (4, 2, 4, 'NO', 'SI', 'SI');
INSERT INTO `permisos-usuarios` VALUES (3, 2, 3, 'NO', 'NO', 'SI');
INSERT INTO `permisos-usuarios` VALUES (2, 2, 2, 'NO', 'SI', 'SI');
INSERT INTO `permisos-usuarios` VALUES (1, 2, 1, 'NO', 'SI', 'SI');

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `persona-padres`
-- 

CREATE TABLE `persona-padres` (
  `IDPERPAR` bigint(50) NOT NULL auto_increment,
  `IDHIJO` bigint(50) NOT NULL default '0',
  `IDPADRE` bigint(50) NOT NULL default '0',
  `IDMADRE` bigint(50) NOT NULL default '0',
  PRIMARY KEY  (`IDPERPAR`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=18 ;

-- 
-- Volcar la base de datos para la tabla `persona-padres`
-- 


-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `personas`
-- 

CREATE TABLE `personas` (
  `IDPERSONA` bigint(50) NOT NULL auto_increment,
  `CEDULA` varchar(30) character set utf8 collate utf8_bin NOT NULL,
  `NOMBRES` varchar(200) character set utf8 collate utf8_bin NOT NULL,
  `APELLIDOS` varchar(200) character set utf8 collate utf8_bin NOT NULL,
  `FECHANACIMIENTO` date default NULL,
  `DIRECCION` text,
  `FONO` varchar(45) default '0',
  `ACTIVO` char(2) NOT NULL,
  `idiglesia` int(11) NOT NULL,
  PRIMARY KEY  (`IDPERSONA`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=76 ;

-- 
-- Volcar la base de datos para la tabla `personas`
-- 

INSERT INTO `personas` VALUES (1, 0x31333131373139323936, 0x484543544f52204d494755454c, 0x47415243c38d4120434f5645c39141, '1989-10-04', 'TOSAGUA', '21', 'SI', 1);
INSERT INTO `personas` VALUES (2, 0x31373134313738373933, 0x4a4f4e415448414e, 0x4c4f50455a, '1988-05-10', 'CENTRO TOSAGUA', '0975643231', 'SI', 1);
INSERT INTO `personas` VALUES (3, 0x31333130363136323631, 0x44415257494e20414e544f4e494f, 0x4d4f52414c45532056454c41535155455a, NULL, 'PORTOVIEJO', '0982394051', '', 1);
INSERT INTO `personas` VALUES (4, 0x31333035323430363731, 0x465245444459, 0x4d4143c38d4153204f5350494e41, NULL, '1212', '262', '', 1);

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `requisitos`
-- 

CREATE TABLE `requisitos` (
  `IDREQUISITO` bigint(50) NOT NULL auto_increment,
  `NOMBRE` char(100) character set utf8 collate utf8_bin default NULL,
  `ACTIVO` varchar(2) default NULL,
  PRIMARY KEY  (`IDREQUISITO`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=7 ;

-- 
-- Volcar la base de datos para la tabla `requisitos`
-- 

INSERT INTO `requisitos` VALUES (1, 0x41435441204f2046452044452042415554495a4d4f, 'SI');
INSERT INTO `requisitos` VALUES (2, 0x434552544946494341444f204445204841424552204150524f4241444f20454c204e4956454c20414e544552494f52, 'SI');

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `tipo_persona`
-- 

CREATE TABLE `tipo_persona` (
  `IDTPER` int(11) NOT NULL auto_increment,
  `NOMBRE` varchar(200) character set utf8 collate utf8_bin default NULL,
  `ACTIVO` varchar(2) default NULL,
  PRIMARY KEY  (`IDTPER`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=16 ;

-- 
-- Volcar la base de datos para la tabla `tipo_persona`
-- 

INSERT INTO `tipo_persona` VALUES (1, 0x455354554449414e544553, 'SI');
INSERT INTO `tipo_persona` VALUES (2, 0x4341544551554953544153, 'SI');
INSERT INTO `tipo_persona` VALUES (3, 0x504152524f434f53, 'SI');

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `tipo_usuario`
-- 

CREATE TABLE `tipo_usuario` (
  `IDTIPO` int(11) NOT NULL auto_increment,
  `NOMBRE` varchar(200) character set utf8 collate utf8_bin NOT NULL,
  `ACTIVO` varchar(2) NOT NULL,
  `idiglesia` int(11) NOT NULL,
  PRIMARY KEY  (`IDTIPO`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=16 ;

-- 
-- Volcar la base de datos para la tabla `tipo_usuario`
-- 

INSERT INTO `tipo_usuario` VALUES (1, 0x41444d494e, 'SI', 1);
INSERT INTO `tipo_usuario` VALUES (2, 0x4f50455241444f52, 'SI', 1);
INSERT INTO `tipo_usuario` VALUES (3, 0x494e56495441444f, 'SI', 1);

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `usuarios`
-- 

CREATE TABLE `usuarios` (
  `IDUSUARIOS` int(11) NOT NULL auto_increment,
  `LOGIN` varchar(45) character set utf8 collate utf8_bin NOT NULL,
  `PASS` varchar(45) character set utf8 collate utf8_bin NOT NULL,
  `TIPO` int(11) NOT NULL,
  `RESPONSABLE` int(11) NOT NULL,
  `idiglesia` int(11) NOT NULL,
  `SSAP` text character set utf8 collate utf8_bin,
  `CON` int(1) default '0',
  `ACTIVO` varchar(2) character set utf8 collate utf8_bin default 'SI',
  PRIMARY KEY  (`IDUSUARIOS`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=5 ;

-- 
-- Volcar la base de datos para la tabla `usuarios`
-- 

INSERT INTO `usuarios` VALUES (1, 0x61646d696e, 0x3832376363623065656138613730366334633334613136383931663834653762, 1, 1, 1, 0x3333393233333238333236343332303033313336, 2, 0x5349);
INSERT INTO `usuarios` VALUES (2, 0x64617277696e, 0x3832376363623065656138613730366334633334613136383931663834653762, 2, 2, 1, 0x3333393233333238333236343332303033313336, 0, 0x5349);
INSERT INTO `usuarios` VALUES (3, 0x6d6163696173, 0x6262383332343062366535613664373337383566656265363465366565633266, 3, 3, 1, 0x373336303632303836373230363333363632303836393736, 0, 0x5349);
INSERT INTO `usuarios` VALUES (4, 0x686563746f72, 0x3361623930373135333664363266323961613862336664333931343166366164, 2, 4, 1, 0x373239363731303437343234363333363634363436363536, 0, 0x5349);

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `ventanas`
-- 

CREATE TABLE `ventanas` (
  `IDVENTANA` bigint(50) NOT NULL auto_increment,
  `NOMBRE` text character set utf8 collate utf8_bin,
  `activo` varchar(2) default NULL,
  PRIMARY KEY  (`IDVENTANA`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=17 ;

-- 
-- Volcar la base de datos para la tabla `ventanas`
-- 

INSERT INTO `ventanas` VALUES (1, 0x56454e54414e4120444520434f4e53554c544120444520455354554449414e544553, 'SI');
INSERT INTO `ventanas` VALUES (2, 0x56454e54414e41204445204341544551554953544153, 'SI');
INSERT INTO `ventanas` VALUES (3, 0x56454e54414e412044452050c38152524f434f53, 'SI');
INSERT INTO `ventanas` VALUES (4, 0x56454e54414e4120444520494e53435249504349c3934e20444520434154455349534d4f, 'SI');
INSERT INTO `ventanas` VALUES (5, 0x56454e54414e412044452042415554495a4f53, 'SI');
INSERT INTO `ventanas` VALUES (6, 0x56454e54414e4120444520434f4e4649524d414349c3934e, 'SI');
INSERT INTO `ventanas` VALUES (7, 0x56454e54414e41204445204d415452494d4f4e494f53, 'SI');
INSERT INTO `ventanas` VALUES (8, 0x56454e54414e41205245504f52544520455354554449414e5445, 'SI');
INSERT INTO `ventanas` VALUES (9, 0x56454e54414e41205245504f52544520414354412044452042415554495a4f53, 'SI');
INSERT INTO `ventanas` VALUES (10, 0x56454e54414e41205245504f525445204143544120444520434f4e4649524d4153, 'SI');
INSERT INTO `ventanas` VALUES (11, 0x56454e54414e41205245504f5254452041435441204445204d415452494d4f4e494f53, 'SI');
INSERT INTO `ventanas` VALUES (12, 0x56454e54414e41204441544f532044452049474c45534941, 'SI');
INSERT INTO `ventanas` VALUES (13, 0x56454e54414e41204e4956454c455320444520434154455349534d4f, 'SI');
INSERT INTO `ventanas` VALUES (14, 0x56454e54414e41205553554152494f53, 'SI');
INSERT INTO `ventanas` VALUES (15, 0x56454e54414e412044495345c3914f, 'SI');
INSERT INTO `ventanas` VALUES (16, 0x4652415345532044454c2053495354454d41, 'SI');
